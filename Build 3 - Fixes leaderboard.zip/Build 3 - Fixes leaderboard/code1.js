gdjs.Main_32MenuCode = {};
gdjs.Main_32MenuCode.localVariables = [];
gdjs.Main_32MenuCode.idToCallbackMap = new Map();
gdjs.Main_32MenuCode.GDFemurImageObjects1= [];
gdjs.Main_32MenuCode.GDFemurImageObjects2= [];
gdjs.Main_32MenuCode.GDNewTextObjects1= [];
gdjs.Main_32MenuCode.GDNewTextObjects2= [];
gdjs.Main_32MenuCode.GDNewText2Objects1= [];
gdjs.Main_32MenuCode.GDNewText2Objects2= [];
gdjs.Main_32MenuCode.GDNewSpriteObjects1= [];
gdjs.Main_32MenuCode.GDNewSpriteObjects2= [];
gdjs.Main_32MenuCode.GDLoadButtonObjects1= [];
gdjs.Main_32MenuCode.GDLoadButtonObjects2= [];
gdjs.Main_32MenuCode.GDLoadButton2Objects1= [];
gdjs.Main_32MenuCode.GDLoadButton2Objects2= [];


gdjs.Main_32MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoadButton"), gdjs.Main_32MenuCode.GDLoadButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDLoadButtonObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDLoadButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDLoadButtonObjects1[k] = gdjs.Main_32MenuCode.GDLoadButtonObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDLoadButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.restoreGameSaveStateFromStorage(runtimeScene, "Autosave-FC2", "default", false);
}
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene");
}
{gdjs.playerAuthentication.removeAuthenticationBanner(runtimeScene);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoadButton2"), gdjs.Main_32MenuCode.GDLoadButton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDLoadButton2Objects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDLoadButton2Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDLoadButton2Objects1[k] = gdjs.Main_32MenuCode.GDLoadButton2Objects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDLoadButton2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}
{gdjs.playerAuthentication.removeAuthenticationBanner(runtimeScene);
}
}

}


};

gdjs.Main_32MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32MenuCode.GDFemurImageObjects1.length = 0;
gdjs.Main_32MenuCode.GDFemurImageObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewTextObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewTextObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewText2Objects1.length = 0;
gdjs.Main_32MenuCode.GDNewText2Objects2.length = 0;
gdjs.Main_32MenuCode.GDNewSpriteObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewSpriteObjects2.length = 0;
gdjs.Main_32MenuCode.GDLoadButtonObjects1.length = 0;
gdjs.Main_32MenuCode.GDLoadButtonObjects2.length = 0;
gdjs.Main_32MenuCode.GDLoadButton2Objects1.length = 0;
gdjs.Main_32MenuCode.GDLoadButton2Objects2.length = 0;

gdjs.Main_32MenuCode.eventsList0(runtimeScene);
gdjs.Main_32MenuCode.GDFemurImageObjects1.length = 0;
gdjs.Main_32MenuCode.GDFemurImageObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewTextObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewTextObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewText2Objects1.length = 0;
gdjs.Main_32MenuCode.GDNewText2Objects2.length = 0;
gdjs.Main_32MenuCode.GDNewSpriteObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewSpriteObjects2.length = 0;
gdjs.Main_32MenuCode.GDLoadButtonObjects1.length = 0;
gdjs.Main_32MenuCode.GDLoadButtonObjects2.length = 0;
gdjs.Main_32MenuCode.GDLoadButton2Objects1.length = 0;
gdjs.Main_32MenuCode.GDLoadButton2Objects2.length = 0;


return;

}

gdjs['Main_32MenuCode'] = gdjs.Main_32MenuCode;
