gdjs.PromoCode = {};
gdjs.PromoCode.localVariables = [];
gdjs.PromoCode.idToCallbackMap = new Map();
gdjs.PromoCode.GDFemurImageObjects1= [];
gdjs.PromoCode.GDFemurImageObjects2= [];
gdjs.PromoCode.GDNewTextObjects1= [];
gdjs.PromoCode.GDNewTextObjects2= [];
gdjs.PromoCode.GDNewText2Objects1= [];
gdjs.PromoCode.GDNewText2Objects2= [];
gdjs.PromoCode.GDNewSpriteObjects1= [];
gdjs.PromoCode.GDNewSpriteObjects2= [];
gdjs.PromoCode.GDLoadButtonObjects1= [];
gdjs.PromoCode.GDLoadButtonObjects2= [];
gdjs.PromoCode.GDLoadButton2Objects1= [];
gdjs.PromoCode.GDLoadButton2Objects2= [];
gdjs.PromoCode.GDNewText3Objects1= [];
gdjs.PromoCode.GDNewText3Objects2= [];


gdjs.PromoCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoadButton"), gdjs.PromoCode.GDLoadButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PromoCode.GDLoadButtonObjects1.length;i<l;++i) {
    if ( gdjs.PromoCode.GDLoadButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.PromoCode.GDLoadButtonObjects1[k] = gdjs.PromoCode.GDLoadButtonObjects1[i];
        ++k;
    }
}
gdjs.PromoCode.GDLoadButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.restoreGameSaveStateFromStorage(runtimeScene, "Autosave-FC2", "default", false);
}
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene");
}
{gdjs.playerAuthentication.removeAuthenticationBanner(runtimeScene);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoadButton2"), gdjs.PromoCode.GDLoadButton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PromoCode.GDLoadButton2Objects1.length;i<l;++i) {
    if ( gdjs.PromoCode.GDLoadButton2Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.PromoCode.GDLoadButton2Objects1[k] = gdjs.PromoCode.GDLoadButton2Objects1[i];
        ++k;
    }
}
gdjs.PromoCode.GDLoadButton2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}
{gdjs.playerAuthentication.removeAuthenticationBanner(runtimeScene);
}
}

}


};

gdjs.PromoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PromoCode.GDFemurImageObjects1.length = 0;
gdjs.PromoCode.GDFemurImageObjects2.length = 0;
gdjs.PromoCode.GDNewTextObjects1.length = 0;
gdjs.PromoCode.GDNewTextObjects2.length = 0;
gdjs.PromoCode.GDNewText2Objects1.length = 0;
gdjs.PromoCode.GDNewText2Objects2.length = 0;
gdjs.PromoCode.GDNewSpriteObjects1.length = 0;
gdjs.PromoCode.GDNewSpriteObjects2.length = 0;
gdjs.PromoCode.GDLoadButtonObjects1.length = 0;
gdjs.PromoCode.GDLoadButtonObjects2.length = 0;
gdjs.PromoCode.GDLoadButton2Objects1.length = 0;
gdjs.PromoCode.GDLoadButton2Objects2.length = 0;
gdjs.PromoCode.GDNewText3Objects1.length = 0;
gdjs.PromoCode.GDNewText3Objects2.length = 0;

gdjs.PromoCode.eventsList0(runtimeScene);
gdjs.PromoCode.GDFemurImageObjects1.length = 0;
gdjs.PromoCode.GDFemurImageObjects2.length = 0;
gdjs.PromoCode.GDNewTextObjects1.length = 0;
gdjs.PromoCode.GDNewTextObjects2.length = 0;
gdjs.PromoCode.GDNewText2Objects1.length = 0;
gdjs.PromoCode.GDNewText2Objects2.length = 0;
gdjs.PromoCode.GDNewSpriteObjects1.length = 0;
gdjs.PromoCode.GDNewSpriteObjects2.length = 0;
gdjs.PromoCode.GDLoadButtonObjects1.length = 0;
gdjs.PromoCode.GDLoadButtonObjects2.length = 0;
gdjs.PromoCode.GDLoadButton2Objects1.length = 0;
gdjs.PromoCode.GDLoadButton2Objects2.length = 0;
gdjs.PromoCode.GDNewText3Objects1.length = 0;
gdjs.PromoCode.GDNewText3Objects2.length = 0;


return;

}

gdjs['PromoCode'] = gdjs.PromoCode;
