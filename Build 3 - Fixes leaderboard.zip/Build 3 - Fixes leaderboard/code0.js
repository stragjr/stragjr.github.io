gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.GDBlueButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDBlueButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDBlueButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects1= [];
gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects2= [];
gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects3= [];
gdjs.Untitled_32sceneCode.GDTotalCookiesObjects1= [];
gdjs.Untitled_32sceneCode.GDTotalCookiesObjects2= [];
gdjs.Untitled_32sceneCode.GDTotalCookiesObjects3= [];
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects1= [];
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2= [];
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects3= [];
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects1= [];
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2= [];
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects3= [];
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects1= [];
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2= [];
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects3= [];


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("IdleUpgrade1"), gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2[k] = gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost")));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost")));
}
{runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought").add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Timer").setNumber(1 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought")));
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2[i].SetLabelTextOp("Bone Factory\nCost: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost")) + "    FPS: +5.0   TFPS: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.roundTo((5.0 * (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought")))), 2)), null);
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought").getAsNumber() > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11742468);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade1");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Upgrade1") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Timer"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(5);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade1");
}
}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("IdleUpgrade2"), gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2[k] = gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost")));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost")));
}
{runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought").add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Timer").setNumber(1 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought")));
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2[i].SetLabelTextOp("Skeleton Hand\nCost: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost")) + "    FPS: +1.0   TFPS: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.roundTo((1.0 * (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought")))), 2)), null);
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought").getAsNumber() > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18044956);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade2");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Upgrade2") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Timer"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade2");
}
}

}


};gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("IdleUpgrade3"), gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2[k] = gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost")));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost")));
}
{runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought").add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Timer").setNumber(1 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought")));
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2[i].SetLabelTextOp("Fossil Mine\nCost: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost")) + "    FPS: +50.0   TFPS: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.roundTo((50.0 * (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought")))), 2)), null);
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought").getAsNumber() > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15102644);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade3");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Upgrade3") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Timer"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade3");
}
}

}


};gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlueButton"), gdjs.Untitled_32sceneCode.GDBlueButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBlueButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBlueButtonObjects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBlueButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDBlueButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBlueButtonObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "112a1755-5bf5-4018-8b45-46b98f238de4", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), gdjs.playerAuthentication.getUsername());
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SmallBlueButton"), gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "112a1755-5bf5-4018-8b45-46b98f238de4", true);
}
}

}


};gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlueButton"), gdjs.Untitled_32sceneCode.GDBlueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.createGameSaveStateInStorage(runtimeScene, "Autosave-FC2", "");
}
}

}


};gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BlueButton"), gdjs.Untitled_32sceneCode.GDBlueButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bone_Image"), gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("IdleUpgrade1"), gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects1);
gdjs.copyArray(runtimeScene.getObjects("IdleUpgrade2"), gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects1);
gdjs.copyArray(runtimeScene.getObjects("IdleUpgrade3"), gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueButton"), gdjs.Untitled_32sceneCode.GDBlueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TotalCookies"), gdjs.Untitled_32sceneCode.GDTotalCookiesObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTotalCookiesObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTotalCookiesObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)))) + " Femurs ");
}
}
}

}


{


gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList4(runtimeScene);
}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDTotalCookiesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTotalCookiesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTotalCookiesObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects3.length = 0;

gdjs.Untitled_32sceneCode.eventsList5(runtimeScene);
gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBone_9595ImageObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDTotalCookiesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTotalCookiesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTotalCookiesObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade1Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDIdleUpgrade3Objects3.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
